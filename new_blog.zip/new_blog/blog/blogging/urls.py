
from django.urls import path
from  .import views
from .views import home,sign,about,detail

urlpatterns = [
path('',home,name='home/'),
path('sign',sign,name='sign/'),
path('about',about,name='about/'),
path('detail/<int:blog_id>/',views.detail,name='detail')
]

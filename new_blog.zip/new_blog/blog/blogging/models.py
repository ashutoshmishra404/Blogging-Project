from django.db import models
from django.contrib.auth.models import User



# PROFILE 
class Profile(models.Model):

    g = (
        ('Male','Male'),
        ('Female','Female')
    )
    
    user=models.OneToOneField(User,on_delete=models.CASCADE,null=True,blank=True)
    name  = models.CharField(max_length=200)
    age   = models.IntegerField()
    email=models.CharField(max_length=200)
    gender=models.CharField(max_length=20,choices=g,default='Male')



class Category(models.Model):
    name= models.CharField(max_length=255)


class Blog(models.Model):
    author = models.ForeignKey(Profile,models.CASCADE,null=True,blank=True,)
    category=models.ForeignKey(Category,on_delete=models.CASCADE,null=True,blank=True)
    title=models.CharField(max_length=20)
    content=models.TextField()
    image=models.ImageField(upload_to='blogs',null=True,blank=True)
    



class Comment(models.Model):
    blog    = models.ForeignKey(Blog,models.CASCADE,null=True,blank=True)
    email   = models.CharField(max_length=200)
    comment =   models.TextField()
    reply   =   models.TextField() 
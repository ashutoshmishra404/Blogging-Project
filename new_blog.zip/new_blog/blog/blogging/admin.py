from django.contrib import admin
from .models import Category
from .models import Profile
from .models import Blog
from .models import Comment

admin.site.register(Category)
admin.site.register(Profile)
admin.site.register(Blog)
admin.site.register(Comment)



from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.http import HttpResponse
from .models import Blog,Category,Profile,Comment


def home(request):
    blogs= Blog.objects.all()
    context={'blogs':blogs}
    return render(request,'home.html',context)

def detail(request,blog_id):
    blog= Blog.objects.get(id=blog_id)
    context={'blog':blog}
    return render(request,'detailing.html',context)


def sign(request):
    if request.method == 'POST':
        
        # USER OJECT CREATION 
        user_obj = User.objects.create(username='',password='')
        # user_obj.set_password(pasword='')
        # user_obj.save()

        # PROFILE OBJECT CREATION 
        Profile.objects.create(
            author = user_obj
        )

    return render(request,'sign.html')

def about(request):

    return render(request,'about.html')

    
def detail(request,blog_id):
    blog= Blog.objects.get(id=blog_id)
    context={'blog':blog}
    return render(request,'detailing.html',context)
    